using UiPath.CodedWorkflows.DescriptorIntegration;

namespace Generate_Yearly_Report_Performer.ObjectRepository
{
    public static class Descriptors
    {
        public static class __Edge_ACME_System_1___Log_In
        {
            static string _reference = "_D6psminDEK3tU8uubjwCA/s-dqAOmVhUaAVMTj904Emw";
            public static _Implementation.___Edge_ACME_System_1___Log_In.__Edge_ACME_System_1 Edge_ACME_System_1 { get; private set; } = new _Implementation.___Edge_ACME_System_1___Log_In.__Edge_ACME_System_1();
            public static _Implementation.___Edge_ACME_System_1___Log_In.__Edge_ACME_System_1___Dashboard Edge_ACME_System_1___Dashboard { get; private set; } = new _Implementation.___Edge_ACME_System_1___Log_In.__Edge_ACME_System_1___Dashboard();
            public static _Implementation.___Edge_ACME_System_1___Log_In.__Edge_ACME_System_1___Dashboard_1_ Edge_ACME_System_1___Dashboard_1_ { get; private set; } = new _Implementation.___Edge_ACME_System_1___Log_In.__Edge_ACME_System_1___Dashboard_1_();
            public static _Implementation.___Edge_ACME_System_1___Log_In.__Edge_ACME_System_1___Download_Monthly_Report Edge_ACME_System_1___Download_Monthly_Report { get; private set; } = new _Implementation.___Edge_ACME_System_1___Log_In.__Edge_ACME_System_1___Download_Monthly_Report();
            public static _Implementation.___Edge_ACME_System_1___Log_In.__Edge_ACME_System_1___Download_Monthly_Report_1_ Edge_ACME_System_1___Download_Monthly_Report_1_ { get; private set; } = new _Implementation.___Edge_ACME_System_1___Log_In.__Edge_ACME_System_1___Download_Monthly_Report_1_();
            public static _Implementation.___Edge_ACME_System_1___Log_In.__Edge_ACME_System_1___Log_In Edge_ACME_System_1___Log_In { get; private set; } = new _Implementation.___Edge_ACME_System_1___Log_In.__Edge_ACME_System_1___Log_In();
            public static _Implementation.___Edge_ACME_System_1___Log_In.__Edge_ACME_System_1___Upload_Yearly_Report Edge_ACME_System_1___Upload_Yearly_Report { get; private set; } = new _Implementation.___Edge_ACME_System_1___Log_In.__Edge_ACME_System_1___Upload_Yearly_Report();
            public static _Implementation.___Edge_ACME_System_1___Log_In.__Edge_ACME_System_1___Work_Items Edge_ACME_System_1___Work_Items { get; private set; } = new _Implementation.___Edge_ACME_System_1___Log_In.__Edge_ACME_System_1___Work_Items();
            public static _Implementation.___Edge_ACME_System_1___Log_In.__Edge_ACME_System_1___Work_Items_1_ Edge_ACME_System_1___Work_Items_1_ { get; private set; } = new _Implementation.___Edge_ACME_System_1___Log_In.__Edge_ACME_System_1___Work_Items_1_();
            public static _Implementation.___Edge_ACME_System_1___Log_In.__Edge_ACME_System_1___Work_Items_2_ Edge_ACME_System_1___Work_Items_2_ { get; private set; } = new _Implementation.___Edge_ACME_System_1___Log_In.__Edge_ACME_System_1___Work_Items_2_();
            public static _Implementation.___Edge_ACME_System_1___Log_In.__New_application New_application { get; private set; } = new _Implementation.___Edge_ACME_System_1___Log_In.__New_application();
        }
    }
}

namespace Generate_Yearly_Report_Performer._Implementation
{
    internal class ScreenDescriptorDefinition : IScreenDescriptorDefinition
    {
        public IScreenDescriptor Screen { get; set; }
        public string Reference { get; set; }
        public string DisplayName { get; set; }
    }

    internal class ElementDescriptorDefinition : IElementDescriptorDefinition
    {
        public IScreenDescriptor Screen { get; set; }
        public string Reference { get; set; }
        public string DisplayName { get; set; }
        public IElementDescriptor ParentElement { get; set; }
        public IElementDescriptor Element { get; set; }
    }

    namespace ___Edge_ACME_System_1___Log_In._Edge_ACME_System_1
    {
        public class _____ : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;

            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public _____(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition
                {
                    Reference = "_D6psminDEK3tU8uubjwCA/9vyLBepGHk6GWSrU8_rjaw",
                    DisplayName = "---",
                    Element = this,
                    ParentElement = _parentElementDescriptor,
                    Screen = screenDescriptor
                };
            }
        }
    }

    namespace ___Edge_ACME_System_1___Log_In._Edge_ACME_System_1
    {
        public class __Add_Comments : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;

            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Add_Comments(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition
                {
                    Reference = "_D6psminDEK3tU8uubjwCA/IPsNorWj9UaiqSqjoXpo_Q",
                    DisplayName = "Add Comments",
                    Element = this,
                    ParentElement = _parentElementDescriptor,
                    Screen = screenDescriptor
                };
            }
        }
    }

    namespace ___Edge_ACME_System_1___Log_In._Edge_ACME_System_1
    {
        public class __OK : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;

            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __OK(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition
                {
                    Reference = "_D6psminDEK3tU8uubjwCA/CIvgDsfSOUCnNZWW1Xpsfw",
                    DisplayName = "OK",
                    Element = this,
                    ParentElement = _parentElementDescriptor,
                    Screen = screenDescriptor
                };
            }
        }
    }

    namespace ___Edge_ACME_System_1___Log_In._Edge_ACME_System_1
    {
        public class __Update_Work_Item : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;

            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Update_Work_Item(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition
                {
                    Reference = "_D6psminDEK3tU8uubjwCA/Pun1ec8OWE-Ug6QmgzFTgg",
                    DisplayName = "Update Work Item",
                    Element = this,
                    ParentElement = _parentElementDescriptor,
                    Screen = screenDescriptor
                };
            }
        }
    }

    namespace ___Edge_ACME_System_1___Log_In
    {
        public class __Edge_ACME_System_1 : IScreenDescriptor
        {
            public IScreenDescriptorDefinition GetDefinition()
            {
                return _screenDescriptor;
            }

            private readonly ScreenDescriptorDefinition _screenDescriptor;

            public __Edge_ACME_System_1()
            {
                _screenDescriptor = new ScreenDescriptorDefinition
                {
                    Reference = "_D6psminDEK3tU8uubjwCA/2NGj2fKK20KObkxr_6gdmw",
                    DisplayName = "Edge ACME System 1",
                    Screen = this
                };
                ___ = new _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1._____(this, null);
                Add_Comments = new _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1.__Add_Comments(this, null);
                OK = new _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1.__OK(this, null);
                Update_Work_Item = new _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1.__Update_Work_Item(this, null);
            }

            public _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1._____ ___ { get; private set; }
            public _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1.__Add_Comments Add_Comments { get; private set; }
            public _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1.__OK OK { get; private set; }
            public _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1.__Update_Work_Item Update_Work_Item { get; private set; }
        }
    }

    namespace ___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Dashboard
    {
        public class __Log_Out : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;

            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Log_Out(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition
                {
                    Reference = "_D6psminDEK3tU8uubjwCA/CwzjdfNNuEOeG-UK3-GJRA",
                    DisplayName = "Log Out",
                    Element = this,
                    ParentElement = _parentElementDescriptor,
                    Screen = screenDescriptor
                };
            }
        }
    }

    namespace ___Edge_ACME_System_1___Log_In
    {
        public class __Edge_ACME_System_1___Dashboard : IScreenDescriptor
        {
            public IScreenDescriptorDefinition GetDefinition()
            {
                return _screenDescriptor;
            }

            private readonly ScreenDescriptorDefinition _screenDescriptor;

            public __Edge_ACME_System_1___Dashboard()
            {
                _screenDescriptor = new ScreenDescriptorDefinition
                {
                    Reference = "_D6psminDEK3tU8uubjwCA/0uKhbQMUaUK7SDWoHDnvUQ",
                    DisplayName = "Edge ACME System 1 - Dashboard",
                    Screen = this
                };
                Log_Out = new _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Dashboard.__Log_Out(this, null);
            }

            public _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Dashboard.__Log_Out Log_Out { get; private set; }
        }
    }

    namespace ___Edge_ACME_System_1___Log_In
    {
        public class __Edge_ACME_System_1___Dashboard_1_ : IScreenDescriptor
        {
            public IScreenDescriptorDefinition GetDefinition()
            {
                return _screenDescriptor;
            }

            private readonly ScreenDescriptorDefinition _screenDescriptor;

            public __Edge_ACME_System_1___Dashboard_1_()
            {
                _screenDescriptor = new ScreenDescriptorDefinition
                {
                    Reference = "_D6psminDEK3tU8uubjwCA/S9YH9yO3h0iGUAnsHlkq6w",
                    DisplayName = "Edge ACME System 1 - Dashboard(1)",
                    Screen = this
                };
            }
        }
    }

    namespace ___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Download_Monthly_Report
    {
        public class _____ : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;

            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public _____(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition
                {
                    Reference = "_D6psminDEK3tU8uubjwCA/V5oe0Vf_dkSB7UMrU2XxpA",
                    DisplayName = "---",
                    Element = this,
                    ParentElement = _parentElementDescriptor,
                    Screen = screenDescriptor
                };
            }
        }
    }

    namespace ___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Download_Monthly_Report
    {
        public class ______1_ : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;

            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public ______1_(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition
                {
                    Reference = "_D6psminDEK3tU8uubjwCA/XsvGh7flG0646cG5skHoZg",
                    DisplayName = "---(1)",
                    Element = this,
                    ParentElement = _parentElementDescriptor,
                    Screen = screenDescriptor
                };
            }
        }
    }

    namespace ___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Download_Monthly_Report
    {
        public class ______2_ : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;

            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public ______2_(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition
                {
                    Reference = "_D6psminDEK3tU8uubjwCA/PkJaJEZ4v0S8F3mxaAFiqQ",
                    DisplayName = "---(2)",
                    Element = this,
                    ParentElement = _parentElementDescriptor,
                    Screen = screenDescriptor
                };
            }
        }
    }

    namespace ___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Download_Monthly_Report
    {
        public class ______3_ : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;

            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public ______3_(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition
                {
                    Reference = "_D6psminDEK3tU8uubjwCA/nTgk1IjBik6JuQed4X1O1w",
                    DisplayName = "---(3)",
                    Element = this,
                    ParentElement = _parentElementDescriptor,
                    Screen = screenDescriptor
                };
            }
        }
    }

    namespace ___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Download_Monthly_Report
    {
        public class ___Save : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;

            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public ___Save(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition
                {
                    Reference = "_D6psminDEK3tU8uubjwCA/iD1Lh-bzjket3Iwwi_IDvA",
                    DisplayName = "&Save",
                    Element = this,
                    ParentElement = _parentElementDescriptor,
                    Screen = screenDescriptor
                };
            }
        }
    }

    namespace ___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Download_Monthly_Report
    {
        public class ___2025 : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;

            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public ___2025(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition
                {
                    Reference = "_D6psminDEK3tU8uubjwCA/5fA54snxyEaojQeh11T6Dg",
                    DisplayName = "2025",
                    Element = this,
                    ParentElement = _parentElementDescriptor,
                    Screen = screenDescriptor
                };
            }
        }
    }

    namespace ___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Download_Monthly_Report
    {
        public class __Button__Save_as_ : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;

            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Button__Save_as_(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition
                {
                    Reference = "_D6psminDEK3tU8uubjwCA/BkEochJLHkSs_6Emdx2jmQ",
                    DisplayName = "Button 'Save as'",
                    Element = this,
                    ParentElement = _parentElementDescriptor,
                    Screen = screenDescriptor
                };
            }
        }
    }

    namespace ___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Download_Monthly_Report
    {
        public class __Close_downloads : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;

            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Close_downloads(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition
                {
                    Reference = "_D6psminDEK3tU8uubjwCA/lzDw1YWpB0uTWioVVXz-dw",
                    DisplayName = "Close downloads",
                    Element = this,
                    ParentElement = _parentElementDescriptor,
                    Screen = screenDescriptor
                };
            }
        }
    }

    namespace ___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Download_Monthly_Report
    {
        public class __Download_Report : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;

            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Download_Report(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition
                {
                    Reference = "_D6psminDEK3tU8uubjwCA/J7IbFeqbzUuQyw9wwqy_Xg",
                    DisplayName = "Download Report",
                    Element = this,
                    ParentElement = _parentElementDescriptor,
                    Screen = screenDescriptor
                };
            }
        }
    }

    namespace ___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Download_Monthly_Report
    {
        public class __Downloads__file_require_ : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;

            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Downloads__file_require_(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition
                {
                    Reference = "_D6psminDEK3tU8uubjwCA/sJzZVhJv9E6FFZ5JtlkG0g",
                    DisplayName = "Downloads, file require…",
                    Element = this,
                    ParentElement = _parentElementDescriptor,
                    Screen = screenDescriptor
                };
            }
        }
    }

    namespace ___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Download_Monthly_Report
    {
        public class __edgedownloadshub : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;

            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __edgedownloadshub(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition
                {
                    Reference = "_D6psminDEK3tU8uubjwCA/qB51nmCHR06m8_YqhxnrTg",
                    DisplayName = "edgedownloadshub",
                    Element = this,
                    ParentElement = _parentElementDescriptor,
                    Screen = screenDescriptor
                };
            }
        }
    }

    namespace ___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Download_Monthly_Report
    {
        public class __edgedownloadshub_1_ : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;

            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __edgedownloadshub_1_(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition
                {
                    Reference = "_D6psminDEK3tU8uubjwCA/F2mUimNATkiZ7wMQ8wb9Bw",
                    DisplayName = "edgedownloadshub(1)",
                    Element = this,
                    ParentElement = _parentElementDescriptor,
                    Screen = screenDescriptor
                };
            }
        }
    }

    namespace ___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Download_Monthly_Report
    {
        public class __File_name : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;

            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __File_name(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition
                {
                    Reference = "_D6psminDEK3tU8uubjwCA/zR8ChV4SVUyiGVsa53uukA",
                    DisplayName = "File name",
                    Element = this,
                    ParentElement = _parentElementDescriptor,
                    Screen = screenDescriptor
                };
            }
        }
    }

    namespace ___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Download_Monthly_Report
    {
        public class __January : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;

            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __January(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition
                {
                    Reference = "_D6psminDEK3tU8uubjwCA/wP9cQvdK3EW2rw3LwpgPcA",
                    DisplayName = "January",
                    Element = this,
                    ParentElement = _parentElementDescriptor,
                    Screen = screenDescriptor
                };
            }
        }
    }

    namespace ___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Download_Monthly_Report
    {
        public class __More_options : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;

            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __More_options(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition
                {
                    Reference = "_D6psminDEK3tU8uubjwCA/j_rQpcCt-kqYa_1TsC1jWg",
                    DisplayName = "More options",
                    Element = this,
                    ParentElement = _parentElementDescriptor,
                    Screen = screenDescriptor
                };
            }
        }
    }

    namespace ___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Download_Monthly_Report
    {
        public class __OK : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;

            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __OK(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition
                {
                    Reference = "_D6psminDEK3tU8uubjwCA/1v1WLLtqWkm_aSZSppyGIA",
                    DisplayName = "OK",
                    Element = this,
                    ParentElement = _parentElementDescriptor,
                    Screen = screenDescriptor
                };
            }
        }
    }

    namespace ___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Download_Monthly_Report
    {
        public class __Open_downloads_page_Cle_ : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;

            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Open_downloads_page_Cle_(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition
                {
                    Reference = "_D6psminDEK3tU8uubjwCA/tsFwAb2IVkiE98LjxpWAAQ",
                    DisplayName = "Open downloads page Cle…",
                    Element = this,
                    ParentElement = _parentElementDescriptor,
                    Screen = screenDescriptor
                };
            }
        }
    }

    namespace ___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Download_Monthly_Report
    {
        public class __Remove_all : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;

            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Remove_all(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition
                {
                    Reference = "_D6psminDEK3tU8uubjwCA/UIAQOBkVJ06AJC-J1rTjww",
                    DisplayName = "Remove all",
                    Element = this,
                    ParentElement = _parentElementDescriptor,
                    Screen = screenDescriptor
                };
            }
        }
    }

    namespace ___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Download_Monthly_Report
    {
        public class __Reports___Download_Mont_ : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;

            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Reports___Download_Mont_(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition
                {
                    Reference = "_D6psminDEK3tU8uubjwCA/124SV9ZQUEm3OW6CvkXXCg",
                    DisplayName = "Reports - Download Mont…",
                    Element = this,
                    ParentElement = _parentElementDescriptor,
                    Screen = screenDescriptor
                };
            }
        }
    }

    namespace ___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Download_Monthly_Report
    {
        public class __Save_as : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;

            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Save_as(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition
                {
                    Reference = "_D6psminDEK3tU8uubjwCA/0gUBjGTIUEu9xKJckUnI2Q",
                    DisplayName = "Save as",
                    Element = this,
                    ParentElement = _parentElementDescriptor,
                    Screen = screenDescriptor
                };
            }
        }
    }

    namespace ___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Download_Monthly_Report
    {
        public class __Save_As : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;

            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Save_As(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition
                {
                    Reference = "_D6psminDEK3tU8uubjwCA/AtZDTDNYlUm5F7CS4j7fig",
                    DisplayName = "Save As",
                    Element = this,
                    ParentElement = _parentElementDescriptor,
                    Screen = screenDescriptor
                };
            }
        }
    }

    namespace ___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Download_Monthly_Report
    {
        public class __unchecked_ : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;

            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __unchecked_(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition
                {
                    Reference = "_D6psminDEK3tU8uubjwCA/nTGuwqV_80-YZHy9HgjyBw",
                    DisplayName = "unchecked",
                    Element = this,
                    ParentElement = _parentElementDescriptor,
                    Screen = screenDescriptor
                };
            }
        }
    }

    namespace ___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Download_Monthly_Report
    {
        public class __Upload_Report : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;

            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Upload_Report(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition
                {
                    Reference = "_D6psminDEK3tU8uubjwCA/mW8sKoZArUW5absmpqPrKw",
                    DisplayName = "Upload Report",
                    Element = this,
                    ParentElement = _parentElementDescriptor,
                    Screen = screenDescriptor
                };
            }
        }
    }

    namespace ___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Download_Monthly_Report
    {
        public class __Vendor_TaxID : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;

            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Vendor_TaxID(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition
                {
                    Reference = "_D6psminDEK3tU8uubjwCA/6bZaiFUx00SA1fow7xVo_g",
                    DisplayName = "Vendor TaxID",
                    Element = this,
                    ParentElement = _parentElementDescriptor,
                    Screen = screenDescriptor
                };
            }
        }
    }

    namespace ___Edge_ACME_System_1___Log_In
    {
        public class __Edge_ACME_System_1___Download_Monthly_Report : IScreenDescriptor
        {
            public IScreenDescriptorDefinition GetDefinition()
            {
                return _screenDescriptor;
            }

            private readonly ScreenDescriptorDefinition _screenDescriptor;

            public __Edge_ACME_System_1___Download_Monthly_Report()
            {
                _screenDescriptor = new ScreenDescriptorDefinition
                {
                    Reference = "_D6psminDEK3tU8uubjwCA/qSFCHMC7OUO3CWTQFXFdAw",
                    DisplayName = "Edge ACME System 1 - Download Monthly Report",
                    Screen = this
                };
                ___ = new _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Download_Monthly_Report._____(this, null);
                ____1_ = new _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Download_Monthly_Report.______1_(this, null);
                ____2_ = new _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Download_Monthly_Report.______2_(this, null);
                ____3_ = new _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Download_Monthly_Report.______3_(this, null);
                _Save = new _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Download_Monthly_Report.___Save(this, null);
                _2025 = new _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Download_Monthly_Report.___2025(this, null);
                Button__Save_as_ = new _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Download_Monthly_Report.__Button__Save_as_(this, null);
                Close_downloads = new _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Download_Monthly_Report.__Close_downloads(this, null);
                Download_Report = new _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Download_Monthly_Report.__Download_Report(this, null);
                Downloads__file_require_ = new _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Download_Monthly_Report.__Downloads__file_require_(this, null);
                edgedownloadshub = new _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Download_Monthly_Report.__edgedownloadshub(this, null);
                edgedownloadshub_1_ = new _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Download_Monthly_Report.__edgedownloadshub_1_(this, null);
                File_name = new _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Download_Monthly_Report.__File_name(this, null);
                January = new _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Download_Monthly_Report.__January(this, null);
                More_options = new _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Download_Monthly_Report.__More_options(this, null);
                OK = new _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Download_Monthly_Report.__OK(this, null);
                Open_downloads_page_Cle_ = new _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Download_Monthly_Report.__Open_downloads_page_Cle_(this, null);
                Remove_all = new _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Download_Monthly_Report.__Remove_all(this, null);
                Reports___Download_Mont_ = new _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Download_Monthly_Report.__Reports___Download_Mont_(this, null);
                Save_as = new _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Download_Monthly_Report.__Save_as(this, null);
                Save_As = new _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Download_Monthly_Report.__Save_As(this, null);
                unchecked_ = new _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Download_Monthly_Report.__unchecked_(this, null);
                Upload_Report = new _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Download_Monthly_Report.__Upload_Report(this, null);
                Vendor_TaxID = new _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Download_Monthly_Report.__Vendor_TaxID(this, null);
            }

            public _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Download_Monthly_Report._____ ___ { get; private set; }
            public _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Download_Monthly_Report.______1_ ____1_ { get; private set; }
            public _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Download_Monthly_Report.______2_ ____2_ { get; private set; }
            public _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Download_Monthly_Report.______3_ ____3_ { get; private set; }
            public _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Download_Monthly_Report.___Save _Save { get; private set; }
            public _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Download_Monthly_Report.___2025 _2025 { get; private set; }
            public _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Download_Monthly_Report.__Button__Save_as_ Button__Save_as_ { get; private set; }
            public _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Download_Monthly_Report.__Close_downloads Close_downloads { get; private set; }
            public _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Download_Monthly_Report.__Download_Report Download_Report { get; private set; }
            public _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Download_Monthly_Report.__Downloads__file_require_ Downloads__file_require_ { get; private set; }
            public _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Download_Monthly_Report.__edgedownloadshub edgedownloadshub { get; private set; }
            public _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Download_Monthly_Report.__edgedownloadshub_1_ edgedownloadshub_1_ { get; private set; }
            public _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Download_Monthly_Report.__File_name File_name { get; private set; }
            public _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Download_Monthly_Report.__January January { get; private set; }
            public _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Download_Monthly_Report.__More_options More_options { get; private set; }
            public _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Download_Monthly_Report.__OK OK { get; private set; }
            public _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Download_Monthly_Report.__Open_downloads_page_Cle_ Open_downloads_page_Cle_ { get; private set; }
            public _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Download_Monthly_Report.__Remove_all Remove_all { get; private set; }
            public _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Download_Monthly_Report.__Reports___Download_Mont_ Reports___Download_Mont_ { get; private set; }
            public _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Download_Monthly_Report.__Save_as Save_as { get; private set; }
            public _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Download_Monthly_Report.__Save_As Save_As { get; private set; }
            public _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Download_Monthly_Report.__unchecked_ unchecked_ { get; private set; }
            public _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Download_Monthly_Report.__Upload_Report Upload_Report { get; private set; }
            public _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Download_Monthly_Report.__Vendor_TaxID Vendor_TaxID { get; private set; }
        }
    }

    namespace ___Edge_ACME_System_1___Log_In
    {
        public class __Edge_ACME_System_1___Download_Monthly_Report_1_ : IScreenDescriptor
        {
            public IScreenDescriptorDefinition GetDefinition()
            {
                return _screenDescriptor;
            }

            private readonly ScreenDescriptorDefinition _screenDescriptor;

            public __Edge_ACME_System_1___Download_Monthly_Report_1_()
            {
                _screenDescriptor = new ScreenDescriptorDefinition
                {
                    Reference = "_D6psminDEK3tU8uubjwCA/UjZxfTlUl0euy6iphd-D0w",
                    DisplayName = "Edge ACME System 1 - Download Monthly Report(1)",
                    Screen = this
                };
            }
        }
    }

    namespace ___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Log_In
    {
        public class __Email : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;

            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Email(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition
                {
                    Reference = "_D6psminDEK3tU8uubjwCA/-UW2QeBob0urerNlsx8WNQ",
                    DisplayName = "Email",
                    Element = this,
                    ParentElement = _parentElementDescriptor,
                    Screen = screenDescriptor
                };
            }
        }
    }

    namespace ___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Log_In
    {
        public class __Login : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;

            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Login(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition
                {
                    Reference = "_D6psminDEK3tU8uubjwCA/qHRJQ1sKwkqcm5lj54T03w",
                    DisplayName = "Login",
                    Element = this,
                    ParentElement = _parentElementDescriptor,
                    Screen = screenDescriptor
                };
            }
        }
    }

    namespace ___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Log_In
    {
        public class __Password : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;

            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Password(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition
                {
                    Reference = "_D6psminDEK3tU8uubjwCA/NLyrIk7GtU--r1UXNlCucA",
                    DisplayName = "Password",
                    Element = this,
                    ParentElement = _parentElementDescriptor,
                    Screen = screenDescriptor
                };
            }
        }
    }

    namespace ___Edge_ACME_System_1___Log_In
    {
        public class __Edge_ACME_System_1___Log_In : IScreenDescriptor
        {
            public IScreenDescriptorDefinition GetDefinition()
            {
                return _screenDescriptor;
            }

            private readonly ScreenDescriptorDefinition _screenDescriptor;

            public __Edge_ACME_System_1___Log_In()
            {
                _screenDescriptor = new ScreenDescriptorDefinition
                {
                    Reference = "_D6psminDEK3tU8uubjwCA/Rs5uyWEKtEyG_dJgBgaUfQ",
                    DisplayName = "Edge ACME System 1 - Log In",
                    Screen = this
                };
                Email = new _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Log_In.__Email(this, null);
                Login = new _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Log_In.__Login(this, null);
                Password = new _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Log_In.__Password(this, null);
            }

            public _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Log_In.__Email Email { get; private set; }
            public _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Log_In.__Login Login { get; private set; }
            public _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Log_In.__Password Password { get; private set; }
        }
    }

    namespace ___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Upload_Yearly_Report
    {
        public class __OK : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;

            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __OK(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition
                {
                    Reference = "_D6psminDEK3tU8uubjwCA/Z1_fowavMkW-P2cxP2HJBQ",
                    DisplayName = "OK",
                    Element = this,
                    ParentElement = _parentElementDescriptor,
                    Screen = screenDescriptor
                };
            }
        }
    }

    namespace ___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Upload_Yearly_Report
    {
        public class __Open : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;

            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Open(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition
                {
                    Reference = "_D6psminDEK3tU8uubjwCA/DOFRG_2ywEKkXiITn-e1YA",
                    DisplayName = "Open",
                    Element = this,
                    ParentElement = _parentElementDescriptor,
                    Screen = screenDescriptor
                };
            }
        }
    }

    namespace ___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Upload_Yearly_Report
    {
        public class __Report_was_uploaded___c_ : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;

            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Report_was_uploaded___c_(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition
                {
                    Reference = "_D6psminDEK3tU8uubjwCA/DFml9T9yw0O_dnUJcrUsdw",
                    DisplayName = "Report was uploaded - c…",
                    Element = this,
                    ParentElement = _parentElementDescriptor,
                    Screen = screenDescriptor
                };
            }
        }
    }

    namespace ___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Upload_Yearly_Report
    {
        public class __Select_Report_File : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;

            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Select_Report_File(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition
                {
                    Reference = "_D6psminDEK3tU8uubjwCA/lBgFM9H6yU-tTVccfZGsAQ",
                    DisplayName = "Select Report File",
                    Element = this,
                    ParentElement = _parentElementDescriptor,
                    Screen = screenDescriptor
                };
            }
        }
    }

    namespace ___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Upload_Yearly_Report
    {
        public class __Vendor_TaxID : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;

            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Vendor_TaxID(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition
                {
                    Reference = "_D6psminDEK3tU8uubjwCA/HizTzC9AyECGrEw5TNlXtQ",
                    DisplayName = "Vendor TaxID",
                    Element = this,
                    ParentElement = _parentElementDescriptor,
                    Screen = screenDescriptor
                };
            }
        }
    }

    namespace ___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Upload_Yearly_Report
    {
        public class __Yearly_Report_2024_FR32_ : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;

            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Yearly_Report_2024_FR32_(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition
                {
                    Reference = "_D6psminDEK3tU8uubjwCA/rn-GbK3zBkO7KFfvNgtpWQ",
                    DisplayName = "Yearly-Report-2024-FR32…",
                    Element = this,
                    ParentElement = _parentElementDescriptor,
                    Screen = screenDescriptor
                };
            }
        }
    }

    namespace ___Edge_ACME_System_1___Log_In
    {
        public class __Edge_ACME_System_1___Upload_Yearly_Report : IScreenDescriptor
        {
            public IScreenDescriptorDefinition GetDefinition()
            {
                return _screenDescriptor;
            }

            private readonly ScreenDescriptorDefinition _screenDescriptor;

            public __Edge_ACME_System_1___Upload_Yearly_Report()
            {
                _screenDescriptor = new ScreenDescriptorDefinition
                {
                    Reference = "_D6psminDEK3tU8uubjwCA/hCzQr3oRE0iJpOSgfftAaw",
                    DisplayName = "Edge ACME System 1 - Upload Yearly Report",
                    Screen = this
                };
                OK = new _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Upload_Yearly_Report.__OK(this, null);
                Open = new _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Upload_Yearly_Report.__Open(this, null);
                Report_was_uploaded___c_ = new _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Upload_Yearly_Report.__Report_was_uploaded___c_(this, null);
                Select_Report_File = new _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Upload_Yearly_Report.__Select_Report_File(this, null);
                Vendor_TaxID = new _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Upload_Yearly_Report.__Vendor_TaxID(this, null);
                Yearly_Report_2024_FR32_ = new _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Upload_Yearly_Report.__Yearly_Report_2024_FR32_(this, null);
            }

            public _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Upload_Yearly_Report.__OK OK { get; private set; }
            public _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Upload_Yearly_Report.__Open Open { get; private set; }
            public _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Upload_Yearly_Report.__Report_was_uploaded___c_ Report_was_uploaded___c_ { get; private set; }
            public _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Upload_Yearly_Report.__Select_Report_File Select_Report_File { get; private set; }
            public _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Upload_Yearly_Report.__Vendor_TaxID Vendor_TaxID { get; private set; }
            public _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Upload_Yearly_Report.__Yearly_Report_2024_FR32_ Yearly_Report_2024_FR32_ { get; private set; }
        }
    }

    namespace ___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Work_Items
    {
        public class __TaxID : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;

            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __TaxID(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition
                {
                    Reference = "_D6psminDEK3tU8uubjwCA/AVdPZPpMC0euOKpw9zcWug",
                    DisplayName = "TaxID",
                    Element = this,
                    ParentElement = _parentElementDescriptor,
                    Screen = screenDescriptor
                };
            }
        }
    }

    namespace ___Edge_ACME_System_1___Log_In
    {
        public class __Edge_ACME_System_1___Work_Items : IScreenDescriptor
        {
            public IScreenDescriptorDefinition GetDefinition()
            {
                return _screenDescriptor;
            }

            private readonly ScreenDescriptorDefinition _screenDescriptor;

            public __Edge_ACME_System_1___Work_Items()
            {
                _screenDescriptor = new ScreenDescriptorDefinition
                {
                    Reference = "_D6psminDEK3tU8uubjwCA/e_neTCYgwki_EbTYtd0izw",
                    DisplayName = "Edge ACME System 1 - Work Items",
                    Screen = this
                };
                TaxID = new _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Work_Items.__TaxID(this, null);
            }

            public _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Work_Items.__TaxID TaxID { get; private set; }
        }
    }

    namespace ___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Work_Items_1_
    {
        public class __Update_Work_Item : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;

            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Update_Work_Item(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition
                {
                    Reference = "_D6psminDEK3tU8uubjwCA/H-_4h-PqY0KKIHAQLYeZ3Q",
                    DisplayName = "Update Work Item",
                    Element = this,
                    ParentElement = _parentElementDescriptor,
                    Screen = screenDescriptor
                };
            }
        }
    }

    namespace ___Edge_ACME_System_1___Log_In
    {
        public class __Edge_ACME_System_1___Work_Items_1_ : IScreenDescriptor
        {
            public IScreenDescriptorDefinition GetDefinition()
            {
                return _screenDescriptor;
            }

            private readonly ScreenDescriptorDefinition _screenDescriptor;

            public __Edge_ACME_System_1___Work_Items_1_()
            {
                _screenDescriptor = new ScreenDescriptorDefinition
                {
                    Reference = "_D6psminDEK3tU8uubjwCA/mUIBbpkg2USv-g-N6T5GCQ",
                    DisplayName = "Edge ACME System 1 - Work Items(1)",
                    Screen = this
                };
                Update_Work_Item = new _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Work_Items_1_.__Update_Work_Item(this, null);
            }

            public _Implementation.___Edge_ACME_System_1___Log_In._Edge_ACME_System_1___Work_Items_1_.__Update_Work_Item Update_Work_Item { get; private set; }
        }
    }

    namespace ___Edge_ACME_System_1___Log_In
    {
        public class __Edge_ACME_System_1___Work_Items_2_ : IScreenDescriptor
        {
            public IScreenDescriptorDefinition GetDefinition()
            {
                return _screenDescriptor;
            }

            private readonly ScreenDescriptorDefinition _screenDescriptor;

            public __Edge_ACME_System_1___Work_Items_2_()
            {
                _screenDescriptor = new ScreenDescriptorDefinition
                {
                    Reference = "_D6psminDEK3tU8uubjwCA/Mg8KHZplo0yZF4XXvra-Pg",
                    DisplayName = "Edge ACME System 1 - Work Items(2)",
                    Screen = this
                };
            }
        }
    }

    namespace ___Edge_ACME_System_1___Log_In._New_application
    {
        public class __Dashboard : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;

            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Dashboard(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition
                {
                    Reference = "_D6psminDEK3tU8uubjwCA/qQxRdNj1kE6MBA8oBaddrA",
                    DisplayName = "Dashboard",
                    Element = this,
                    ParentElement = _parentElementDescriptor,
                    Screen = screenDescriptor
                };
            }
        }
    }

    namespace ___Edge_ACME_System_1___Log_In
    {
        public class __New_application : IScreenDescriptor
        {
            public IScreenDescriptorDefinition GetDefinition()
            {
                return _screenDescriptor;
            }

            private readonly ScreenDescriptorDefinition _screenDescriptor;

            public __New_application()
            {
                _screenDescriptor = new ScreenDescriptorDefinition
                {
                    Reference = "_D6psminDEK3tU8uubjwCA/rmTpUHvTaku0pQdMlHYCVA",
                    DisplayName = "New application",
                    Screen = this
                };
                Dashboard = new _Implementation.___Edge_ACME_System_1___Log_In._New_application.__Dashboard(this, null);
            }

            public _Implementation.___Edge_ACME_System_1___Log_In._New_application.__Dashboard Dashboard { get; private set; }
        }
    }
}